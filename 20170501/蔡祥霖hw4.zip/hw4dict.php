<?php
$dict = ["apple"=>"蘋果","orange"=>"橘子","watermelon"=>"西瓜","strawberry"=>"草莓","pineapple"=>"鳳梨"];
       

?>